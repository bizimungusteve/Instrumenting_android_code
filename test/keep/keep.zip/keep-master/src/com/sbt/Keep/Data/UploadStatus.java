package com.sbt.Keep.Data;

public enum UploadStatus {
	Pending, Queue, Completed;
}
